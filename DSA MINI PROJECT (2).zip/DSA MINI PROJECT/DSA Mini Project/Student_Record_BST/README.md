# Student Record Search System Using Trees

A menu-driven C++17 implementation of a Binary Search Tree (BST) for student records, based on the supplied PPF Week 9 brief.

## Features
- Student record: unique integer enrolment ID, name, department/programme.
- Insert with duplicate-ID rejection.
- Search by enrolment ID.
- Delete leaf, one-child, and two-child nodes.
- Inorder, preorder, and postorder traversals.
- Inorder displays records in ascending enrolment-ID order.
- Comparison-count demonstration for balanced-looking and sorted insertion orders.

## Build and run
**Linux/macOS (g++):**
```bash
g++ -std=c++17 -Wall -Wextra -pedantic main.cpp -o student_record_bst
./student_record_bst
```
**Windows (MinGW g++):**
```bash
g++ -std=c++17 -Wall -Wextra -pedantic main.cpp -o student_record_bst.exe
student_record_bst.exe
```

## Quick demo
Insert at least these 10 records (IDs can be your own test values):
`50, 30, 70, 20, 40, 60, 80, 10, 25, 35`. Use fictional names/departments for testing. Try searching for an existing ID and a missing ID, then run all traversals. Option 7 shows insertion-comparison counts for two orders.

## Complexity
Let h be the BST height and n the number of records.
- Insert/search/delete: O(h) time; average O(log n) for a reasonably balanced tree, worst-case O(n) for a skewed tree.
- Traversals: O(n) time.
- Tree storage: O(n); recursive traversal/deletion stack can be O(h).
- An AVL/self-balancing tree rotates after updates to keep height O(log n), so core operations remain O(log n).

## Test cases
See `REPORT.md` for leaf, one-child, two-child deletion, duplicate-ID, search, and traversal tests.

## Screenshots for submission
Capture your own terminal screenshots after running the program: insertion of 10 records, successful and unsuccessful search, inorder/preorder/postorder outputs, duplicate rejection, each deletion case, and comparison demo.
