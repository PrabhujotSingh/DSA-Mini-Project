# Campus Route Finder Using Graphs

A menu-driven C++17 DSA mini project based on the supplied PPF Week 9 brief.

## Features
- 9 campus locations represented as vertices.
- Undirected adjacency-list graph.
- BFS shortest route in an unweighted graph, including parent-based path reconstruction.
- Iterative DFS traversal of reachable locations.
- Reports locations unreachable from a selected start.
- Handles invalid location names and invalid menu choices.

## Build and run
**Linux/macOS (g++):**
```bash
g++ -std=c++17 -Wall -Wextra -pedantic main.cpp -o campus_route_finder
./campus_route_finder
```
**Windows (MinGW g++):**
```bash
g++ -std=c++17 -Wall -Wextra -pedantic main.cpp -o campus_route_finder.exe
campus_route_finder.exe
```

Enter location names exactly as displayed, e.g. `Main Gate`, `Library`, `Lab`.

## Complexity
Let V be the number of locations and E the number of paths.
- BFS: O(V + E) time with adjacency lists; O(V) auxiliary space.
- DFS: O(V + E) time with adjacency lists; O(V) auxiliary space.
- Adjacency list: O(V + E) space; best suited to sparse graphs.
- Adjacency matrix: O(V^2) space; checking whether an edge exists is O(1), but scanning neighbors is O(V).

## Test cases
1. Direct route: `Main Gate` to `Library` => `Main Gate -> Library` (1 edge).
2. Multi-stop route: `Main Gate` to `Lab` => `Main Gate -> Library -> Block 1 -> Lab` (3 edges).
3. Invalid destination: `Main Gate` to `Hostel` => clear invalid-location message.
4. DFS: start at `Main Gate` => all nine locations are reachable in this sample graph.
5. Disconnected check from `Main Gate` => `None (all locations are connected)`.

## Screenshots for submission
Run the program in a terminal and capture screenshots of: graph input/adjacency list, BFS direct route, BFS multi-stop route, DFS traversal, and test cases. Screenshots must be captured from your own run; they are intentionally not fabricated here.
