# Mini Project Report: Campus Route Finder Using Graphs

## Aim
To model campus places and connecting paths as an unweighted graph, then use BFS and DFS to explore routes and reachability.

## Data structure
Each campus location is a vertex. Each walkway/path is an undirected edge. The graph is stored as an adjacency list (`vector<vector<int>>`), avoiding the O(V^2) storage cost of a matrix for a sparse graph.

## Algorithms
- **BFS:** Uses a queue and visited array. A parent array stores each discovered vertex's predecessor. Once the destination is reached, following parent links backwards reconstructs a route with the minimum number of edges.
- **DFS:** Uses an explicit stack and visited array to traverse reachable vertices.
- **Reachability/disconnected check:** BFS marks all vertices reachable from the chosen source; unmarked vertices are reported as unreachable.

## Complexity
With an adjacency list, BFS and DFS each take O(V + E) time and O(V) auxiliary space. An adjacency matrix takes O(V^2) space and requires O(V) time to scan a vertex's possible neighbors.

## Sample test results
- Main Gate -> Library: 1 edge.
- Main Gate -> Library -> Block 1 -> Lab: 3 edges.
- Unknown location `Hostel`: rejected with an explanatory message.
- From Main Gate, all defined sample locations are reachable.

## Limitations and possible extension
The sample campus map is hard-coded and assumes every path has equal cost. Future versions could accept user-defined paths and use Dijkstra's algorithm for weighted distances.
